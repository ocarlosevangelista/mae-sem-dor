Landing page package: Amamentacao Sem Dor em 7 Dias - Metodo Antifissura
Files included:
- index.html
- styles.css
- script.js
- assets/ (contains any uploaded files included)

Reference file paths from the conversation (local):
- /mnt/data/Curso para mulheres.docx
- /mnt/data/PDF - Webinário  Russell Brunson - Icaro de Carvalho.pdf

To deploy: upload the ZIP to Netlify (drag & drop) and publish.
